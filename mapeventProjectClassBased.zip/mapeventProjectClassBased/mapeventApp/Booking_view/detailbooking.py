from django.views.generic import TemplateView
from mapeventApp.models import Event
from django.contrib.auth.mixins import  LoginRequiredMixin

class DetailBookingAdmin(LoginRequiredMixin,TemplateView):
    template_name = 'detail_booking.html'
    def get_context_data(self, **event):
    	context = super(DetailBookingAdmin, self).get_context_data(**event)
    	query = Event.objects.filter(event=event['event']).all()
    	context = {'admin_booking_detail':query}
    	return  context