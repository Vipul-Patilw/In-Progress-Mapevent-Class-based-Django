from django.views.generic import ListView,TemplateView
from mapeventApp.models import Event
from django.contrib.auth.mixins import  LoginRequiredMixin

class ListBookingAdmin(LoginRequiredMixin,ListView):
    template_name = 'list_booking.html'
    context_object_name = 'admin_booking_list'
    queryset  = {'unique':Event.objects.all().values_list('event', flat=True).distinct(),'count':Event.objects.all().count()}
    
 
class ListBookingUser(LoginRequiredMixin,TemplateView):
    template_name = 'list_booking.html'
    def get_context_data(self, **email):
    	context = super(ListBookingUser, self).get_context_data(**email)
    	query = Event.objects.filter(email=email['email']).all()
    	context = {'user_booking_list':query}
    	return  context
    
    