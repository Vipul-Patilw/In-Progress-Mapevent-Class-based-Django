from quopri import decodestring
from mapeventApp.models import Login
import re
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from mapeventProject import settings
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_decode
from django.core.mail import EmailMessage
from django import forms

class UserCreateForm(forms.ModelForm):
	model = Login
	fields = '__all__'
	labels = {
	'first_name': 'First Name',
	
	'last_name':'Last Name',
	
	'mobile_number':'Mobile Number',
	
	'username':'Username',
		
	'email':'Email',

	'password':'Password',
	
	'gender':'Gender',

	'birthdate':'Birthdate'
}


#def index(request):
#	try:
#		if request.method =="POST":
#		
#			first_name = request.POST.get('first_name')
#			last_name = request.POST.get('last_name')
#			mobile_number= request.POST.get('mobile_number')
#			username= request.POST.get('username')
#			email = request.POST.get('email')
#			password= request.POST.get('password')
#			gender = request.POST.get('gender')
#			birthdate = request.POST.get('birthdate')
#			password2 = request.POST.get('password2')
#			
#		
#			if User.objects.filter(email=email):
#						messages.error(request,"this email address already registered with us try different email address")
#						return redirect("/sign")
#						
#			if User.objects.filter(username=username):
#						messages.error(request,"this username is already exist try another")
#						return redirect("/sign")

#			if password != password2:
#				messages.error(request,"confirm password doesn't matched with the password")
#				return redirect ('/sign')
#				
#			if len(password)>=8 and re.search(r"[A-Z]",password) and re.search(r"[a-z]",password) and re.search(r"[@_!#$%^&*()?/}{~:]",password)and re.search(r"[0-9]",password):
#				pass
#				
#			else:
#				messages.error(request,"password should be at least 6 character long. contain both uppercase and lowercase character, at least one alpha numeric and one special charecter  (eg:Test@123)")
#				return redirect("/sign")
#				

#			messages.success(request, first_name.title() + " " + last_name.title())
#			myuser = User.objects.create_user(username,email,password)
#			myuser.first_name = first_name
#			myuser.last_name = last_name
#			myuser.is_active = True
#			myuser.save()	
#			
#			users = Login(first_name=first_name,username=username, mobile_number=mobile_number,last_name=last_name,email=email,birthdate=birthdate,gender=gender,)
#			users.save()		
#			
#			#confirmation email
#			current_site = get_current_site(request)
#			email_sub2 = 'Activate your MCCIA Account'
#			message2 = render_to_string('email_confirmation.html',{
#				'fname': myuser.first_name,
#				'lname': myuser.last_name, 
#				'domain': current_site.domain,
#				'uid': urlsafe_base64_encode(force_bytes(myuser.pk)),
#				'token': generate_token.make_token(myuser)
#				})
#			email = EmailMessage(
#				email_sub2,
#				message2,
#				settings.EMAIL_HOST_USER,
#				[myuser.email],
#				)
#			
#			email.fail_silently= True
#			email.send()

#			
#			return render(request, 'gotologin.html')

#		return render(request, 'logininfo.html')
#	except:
#		messages.error(request,"since google disabled the smpt from 30may2022 we are not able to send mail.So you don't need confirmation link we activate your account you can login now")
#		return redirect('/gotologin')
