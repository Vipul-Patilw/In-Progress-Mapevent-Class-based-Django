from django.views.generic.edit import DeleteView
from mapeventApp.models import  AddEvent
class DeleteEvent(DeleteView):
		model = AddEvent
		template_name = 'delete_event.html'
		success_url = '/eventeditpage'