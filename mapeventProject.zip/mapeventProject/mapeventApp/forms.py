from mapeventApp.events_form.addevent import  AddEventForm
from mapeventApp.registration_form.userlogin import  UserCreateForm

AddEventForm
UserCreateForm
