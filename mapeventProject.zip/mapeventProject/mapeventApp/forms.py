from mapeventApp.eventsform.addevent import  AddEventForm

AddEventForm
