from django.shortcuts import redirect, render
from geopy.geocoders import Nominatim
from mapeventApp.models import AddEvent
from django.contrib import messages
from django import forms

class AddEventForm(forms.ModelForm):
	
	class Meta:
		model = AddEvent
		fields = ['event','info','eventaddress','fromdate','todate','fromtime','totime','icon','eventermail','city','locate']
		labels ={ 'event': ('Event'), 'info': ('Event Details'),'eventaddress': ('Event Address'),}
		widgets = {'fromdate':forms.DateInput(attrs={'type':'date'}),'todate':forms.DateInput(attrs={'type':'date'})}
	#	event = forms.CharField(max_length=100,label="Event")
#		info = forms.CharField(max_length=222,label="Event Details")
#		eventaddress = forms.CharField(max_length=222,label="Event Address")
#		fromdate = forms.DateField(label="Date From",widget=forms.DateInput())
#		todate= forms.DateField(label="Date Till",widget=forms.DateInput)
#		fromtime = forms.TimeField(label="Time From",widget=forms.TimeInput())
#		totime= forms.TimeField(label="Time Till",widget=forms.TimeInput())
#		icon_choices= [('bar-15','bar-15'),('music-15','music-15'),('art-gallery-15','art-gallery-15')]
#		icon = forms.CharField(max_length=12, widget=forms.Select(choices=icon_choices,attrs={'class':'inputing'}),label="Choose an icon")
#		eventermail = forms.EmailField(label="Enter Owner E-mail Id")
#	#	city_choices=(('mumbai','mumbai'),('pune','pune'),('delhi','delhi'),('kolkatta','kolkatta'))
#		#city = forms.CharField(max_length=10, choices=city_choices, default='pune',label="Choose an city")
#		locate = forms.CharField(max_length=122,label="Excact Location of event (eg:wakad)")
#		
		def location_conver_to_lat_lang(self):
				
				locate = AddEvent.locate#self.cleaned_data.get('locate', '')	
				geolocator = Nominatim(user_agent="MyApp")
				location = geolocator.geocode(locate)
				lang = location.longitude
				lat = location.latitude
				addevent = AddEvent(lang=lang,lat=lat,location=location)
				addevent.save()
				
#				
#				
#			#	return  redirect('/map')
#	except:
#			messages.error(request,"Excat location of event which you enter is invalid. please check if it don't have any spelling mistakes if it is still not working try with some official locations")
#			return redirect('/addevent')
#	return render (request, 'addevent.html')